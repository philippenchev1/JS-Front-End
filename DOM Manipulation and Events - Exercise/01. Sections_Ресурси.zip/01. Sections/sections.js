document.addEventListener('DOMContentLoaded', solve);

function solve() {
   // TODO
}